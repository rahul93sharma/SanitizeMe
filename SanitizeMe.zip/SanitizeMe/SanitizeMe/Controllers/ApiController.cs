﻿using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;
using System.Xml;
using HttpGetAttribute = System.Web.Http.HttpGetAttribute;
using RouteAttribute = System.Web.Http.RouteAttribute;

namespace SanitizeMe.Controllers
{
    public class ApiController : Controller
    {
       
        [System.Web.Http.HttpPost]
        [Route("api/details")]
        public string ReturnXmlDocument(HttpRequestMessage request)
        {
            var doc = new XmlDocument();
            doc.Load(request.Content.ReadAsStreamAsync().Result);
            return doc.DocumentElement.OuterXml;
        }

        [HttpGet]
        [Route("Api/Getmethod/{id}")]
        // GET: Api/Delete/5
        public string Getmethod(int id)
        {
            return "";
        }

    }
}

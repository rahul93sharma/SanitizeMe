﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace testing
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args != null && args.Length > 0)
            {
                args = Array.ConvertAll(args, x => x.ToLower());
                if (args[0].Equals("copydefaultdb"))
                {
                    string file = @"D:\Robosharp\Destination\Copyfile.db";
                    string str = file.Replace("Copyfile", "copydefaultdb");
                    File.Copy(file, str, true);
                }
                if (args[0].Equals("resetdb"))
                {
                    string file = @"D:\Robosharp\Destination\Copyfile.db";
                    string str = file.Replace("Copyfile", "resetdb");
                    File.Copy(file, str, true);
                }
                if(args.Contains("copydefaultdb"))
                {
                    string file = @"D:\Robosharp\Destination\Copyfile.db";
                    string str = file.Replace("Copyfile", "contains");
                    File.Copy(file, str, true);
                }
                if (args.Contains("resetdb"))
                {
                    string file = @"D:\Robosharp\Destination\Copyfile.db";
                    string str = file.Replace("Copyfile", "resetdb");
                    File.Copy(file, str, true);
                }
                string file1 = @"D:\Robosharp\Destination\Copyfile.db";
                string str1 = file1.Replace("Copyfile", "copydefaultdb");
                File.Copy(file1, str1, true);
            }
            string noarguments = "";
        }
    }
}

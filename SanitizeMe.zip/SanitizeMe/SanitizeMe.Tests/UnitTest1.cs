﻿using System;
using System.IO;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace SanitizeMe.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            string file = @"D:\Robosharp\Destination\Copyfile.db";
            string str = file.Replace("Copyfile","newfile");
            if(!File.Exists(str))
              File.Copy(file, str);

        }
    }
}
